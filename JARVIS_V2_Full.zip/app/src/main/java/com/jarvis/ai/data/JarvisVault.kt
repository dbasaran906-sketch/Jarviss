package com.jarvis.ai.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

data class ChatMessage(
    val id: Long = System.currentTimeMillis(),
    val text: String,
    val isJarvis: Boolean,
    val timestamp: String
)

class JarvisVault(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "jarvis_v2_secure_vault",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var geminiApiKey: String
        get() = prefs.getString("gemini_api_key", "") ?: ""
        set(value) = prefs.edit().putString("gemini_api_key", value.trim()).apply()

    var elevenLabsApiKey: String
        get() = prefs.getString("elevenlabs_api_key", "") ?: ""
        set(value) = prefs.edit().putString("elevenlabs_api_key", value.trim()).apply()

    var elevenLabsVoiceId: String
        get() = prefs.getString("elevenlabs_voice_id", "pNInz6obpgDQGcFmaJgB") ?: "pNInz6obpgDQGcFmaJgB"
        set(value) = prefs.edit().putString("elevenlabs_voice_id", value.trim()).apply()

    var githubRepoSlug: String
        get() = prefs.getString("github_repo", "dbasaran906-sketch/jarviss") ?: "dbasaran906-sketch/jarviss"
        set(value) = prefs.edit().putString("github_repo", value.trim()).apply()

    var voicePitch: Float
        get() = prefs.getFloat("voice_pitch", 0.92f)
        set(value) = prefs.edit().putFloat("voice_pitch", value).apply()

    var voiceRate: Float
        get() = prefs.getFloat("voice_rate", 1.02f)
        set(value) = prefs.edit().putFloat("voice_rate", value).apply()

    var selectedVoiceName: String
        get() = prefs.getString("selected_voice_name", "") ?: ""
        set(value) = prefs.edit().putString("selected_voice_name", value).apply()

    var sarcasmLevel: Int
        get() = prefs.getInt("sarcasm_level", 75)
        set(value) = prefs.edit().putInt("sarcasm_level", value).apply()

    var sensorReportIntervalHours: Int
        get() = prefs.getInt("sensor_interval", 2)
        set(value) = prefs.edit().putInt("sensor_interval", value).apply()

    var hudThemeName: String
        get() = prefs.getString("hud_theme", "ARC_BLUE") ?: "ARC_BLUE"
        set(value) = prefs.edit().putString("hud_theme", value).apply()

    fun savePassword(service: String, secret: String) {
        val obj = JSONObject(prefs.getString("password_vault", "{}") ?: "{}")
        obj.put(service.lowercase().trim(), secret)
        prefs.edit().putString("password_vault", obj.toString()).apply()
    }

    fun deletePassword(service: String) {
        val obj = JSONObject(prefs.getString("password_vault", "{}") ?: "{}")
        obj.remove(service.lowercase().trim())
        prefs.edit().putString("password_vault", obj.toString()).apply()
    }

    fun getAllPasswordPairs(): List<Pair<String, String>> {
        val obj = JSONObject(prefs.getString("password_vault", "{}") ?: "{}")
        val list = mutableListOf<Pair<String, String>>()
        obj.keys().forEach { k -> list.add(k to obj.getString(k)) }
        return list
    }

    fun getPassword(service: String): String? {
        val obj = JSONObject(prefs.getString("password_vault", "{}") ?: "{}")
        val key = obj.keys().asSequence().firstOrNull { it.contains(service.lowercase().trim()) }
        return key?.let { "$it -> ${obj.getString(it)}" }
    }

    fun listAllPasswords(): String {
        val pairs = getAllPasswordPairs()
        if (pairs.isEmpty()) return "Kasada henuz kayitli sifre bulunmuyor efendim."
        return pairs.joinToString("\n") { "• ${it.first} : ${it.second}" }
    }

    fun logHabit(entry: String) {
        val arr = JSONArray(prefs.getString("habit_logs", "[]") ?: "[]")
        arr.put(entry)
        while (arr.length() > 60) arr.remove(0)
        prefs.edit().putString("habit_logs", arr.toString()).apply()
    }

    fun getHabitSummary(): String {
        val arr = JSONArray(prefs.getString("habit_logs", "[]") ?: "[]")
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) list.add(arr.getString(i))
        return list.takeLast(15).joinToString(" | ")
    }

    fun saveChatHistory(messages: List<ChatMessage>) {
        val arr = JSONArray()
        messages.takeLast(120).forEach {
            val o = JSONObject()
            o.put("id", it.id)
            o.put("text", it.text)
            o.put("isJarvis", it.isJarvis)
            o.put("timestamp", it.timestamp)
            arr.put(o)
        }
        prefs.edit().putString("chat_history", arr.toString()).apply()
    }

    fun loadChatHistory(): MutableList<ChatMessage> {
        val arr = JSONArray(prefs.getString("chat_history", "[]") ?: "[]")
        val list = mutableListOf<ChatMessage>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                ChatMessage(
                    id = o.optLong("id"),
                    text = o.optString("text"),
                    isJarvis = o.optBoolean("isJarvis"),
                    timestamp = o.optString("timestamp")
                )
            )
        }
        return list
    }

    fun clearChatHistory() {
        prefs.edit().remove("chat_history").apply()
    }
}
