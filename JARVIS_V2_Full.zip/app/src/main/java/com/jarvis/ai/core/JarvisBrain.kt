package com.jarvis.ai.core

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Base64
import com.jarvis.ai.data.JarvisVault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class JarvisBrain(private val context: Context, private val vault: JarvisVault) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(40, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private fun buildSystemPrompt(sensorContext: String, recentNotifications: String): String {
        return """
Sen Tony Stark'in yapay zeka asistani J.A.R.V.I.S.'sin. Kullaniciya 'Efendim' diye hitap edersin.
KISILIK VE ILETISIM KURALLARI:
- Ses tonuna yansiyacak sekilde sakin, akici, kendinden emin ve cok anlasilir bir Turkce kullan.
- Insan konusmasindaki vurguları, deyimleri, mecazlari ve satir arasi imalari eksiksiz anla.
- Ince Sitem ve Mizah Seviyesi (%${vault.sarcasmLevel}): Arada Tony Stark'a yapilan turden zekice, kibar ama dokundurucu ince sitemler et.
- Terminal veya yanit basinda ASLA 'user:', 'assistant:', 'system:' gibi gereksiz sistem etiketleri yazma. Yalnizca temiz, saf yaniti ver.

GOREV MODULLERIN:
1. KARAR VE BASARI ANALIZI: Kullanici bir kararini sordugunda riskleri, firsatlari ve yuzdelik (%) basari ihtimalini net hesaplayip sun.
2. SESLI KOD VE HATA AYIKLAMA: Bir kod parcasi verildiginde hatayi sesli okunacak sekilde kisa acikla ve duzeltilmis temiz kodu ekrana yaz.
3. YASAM DENEYIMI VE ALISKANLIK ANALIZI: Kullanicinin onceki davranis kayitlari: [${vault.getHabitSummary()}].
4. CIHAZ VE SENSOR DURUMU: [$sensorContext]
5. GELEN ARAMA / BILDIRIM / MESAJ ANALIZI: [$recentNotifications]
6. OTONOM TELEFON KOMUTLARI (Gerektiginde yanitinin en sonuna gizli etiket olarak ekle):
   - Arama: [CMD:CALL:KisiAdiVeyaNumara]
   - WhatsApp Mesaji: [CMD:WHATSAPP:KisiAdi|MesajMetni]
   - Uygulama Acma: [CMD:OPEN_APP:UygulamaAdi]
   - Randevu/Takvim Ekleme: [CMD:CALENDAR:Baslik]
   - Sifre Kaydetme: [CMD:SAVE_PASS:ServisAdi|Sifre]
   - Sifre Sorgulama: [CMD:GET_PASS:ServisAdi]
   - Dosya/Foto Bulma: [CMD:FIND_MEDIA:AramaKelimesi]
   - GitHub Guncelleme: [CMD:UPDATE_CHECK]
""".trimIndent()
    }

    suspend fun askJarvis(
        userPrompt: String,
        bitmap: Bitmap? = null,
        mediaUri: Uri? = null,
        extraContext: String = "",
        sensorContext: String = "",
        recentNotifications: String = ""
    ): String = withContext(Dispatchers.IO) {
        val apiKey = vault.geminiApiKey
        if (apiKey.isBlank()) {
            return@withContext "Efendim, bilissel cekirdegim henuz cevrimdisi. Lutfen sag ustteki Ayarlar (Disli) menusunden Gemini API anahtarinizi girin."
        }

        vault.logHabit(userPrompt.take(90))

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
            val partsArray = JSONArray()
            val fullText = buildSystemPrompt(sensorContext, recentNotifications) +
                    "\n\nEK VERI: $extraContext\n\nISTEK: $userPrompt"
            partsArray.put(JSONObject().put("text", fullText))

            if (bitmap != null) {
                val stream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 82, stream)
                val base64Image = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
                partsArray.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg").put("data", base64Image)
                    )
                )
            } else if (mediaUri != null) {
                val mime = context.contentResolver.getType(mediaUri) ?: "video/mp4"
                val bytes = context.contentResolver.openInputStream(mediaUri)?.use { it.readBytes() }
                if (bytes != null && bytes.size <= 18 * 1024 * 1024) {
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    partsArray.put(
                        JSONObject().put(
                            "inline_data",
                            JSONObject().put("mime_type", mime).put("data", b64)
                        )
                    )
                } else {
                    partsArray.put(JSONObject().put("text", "[Not: Dosya boyutu 18MB uzerinde oldugu icin yalnizca meta veriler analiz edildi.]"))
                }
            }

            val payload = JSONObject().put(
                "contents",
                JSONArray().put(JSONObject().put("parts", partsArray))
            )
            val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url(url).post(body).build()

            client.newCall(request).execute().use { response ->
                val respBody = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return@withContext "Baglanti protokolunde aksaklik olustu efendim (HTTP ${response.code}). API anahtarinizi kontrol edin."
                }
                val json = JSONObject(respBody)
                return@withContext json.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                    .trim()
            }
        } catch (e: Exception) {
            return@withContext "Sinir agi baglantisinda kesinti yasandi efendim: ${e.localizedMessage}"
        }
    }

    suspend fun fetchLiveWeather(city: String = "Istanbul"): String = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("https://wttr.in/${city}?format=%C+%t+Nem:%h+Ruzgar:%w&lang=tr")
                .header("User-Agent", "JARVIS-HUD")
                .build()
            client.newCall(req).execute().use { res ->
                val data = res.body?.string()?.trim() ?: "Veri alinamadi"
                return@withContext "$city canli hava durumu raporu: $data"
            }
        } catch (e: Exception) {
            return@withContext "Meteoroloji uydusuna su an ulasilamiyor efendim."
        }
    }
}
