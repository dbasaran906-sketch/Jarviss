package com.jarvis.ai.hardware

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.usb.UsbManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.Socket
import java.util.UUID

data class RadarTarget(
    val name: String,
    val address: String,
    val type: String,
    val rssi: Int,
    val angleDeg: Float,
    val distanceNorm: Float
)

class JarvisHardwareManager(private val context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    private val _radarTargets = MutableStateFlow<List<RadarTarget>>(emptyList())
    val radarTargets: StateFlow<List<RadarTarget>> = _radarTargets

    private val _telemetrySummary = MutableStateFlow("Sistemler Normal | Sicaklik: 32.0°C")
    val telemetrySummary: StateFlow<String> = _telemetrySummary

    private var accelData = "0.0, 0.0, 9.8"
    private var gyroData = "0.0, 0.0, 0.0"
    private var lightLux = 120f

    fun startSensors() {
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        updateTelemetry()
    }

    fun stopSensors() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                accelData = String.format("%.1f, %.1f, %.1f", event.values[0], event.values[1], event.values[2])
            }
            Sensor.TYPE_GYROSCOPE -> {
                gyroData = String.format("%.2f, %.2f, %.2f", event.values[0], event.values[1], event.values[2])
            }
            Sensor.TYPE_LIGHT -> {
                lightLux = event.values[0]
            }
        }
        updateTelemetry()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    fun getBatteryTempCelsius(): Float {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300) ?: 300
        return temp / 10f
    }

    fun getBatteryLevel(): Int {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 85) ?: 85
    }

    private fun updateTelemetry() {
        val temp = getBatteryTempCelsius()
        val bat = getBatteryLevel()
        _telemetrySummary.value = "Batarya: %$bat (${temp}°C) | Isik: ${lightLux.toInt()} lx | Ivme: [$accelData] | Jiro: [$gyroData]"
    }

    @SuppressLint("MissingPermission")
    fun scanEnvironmentRadar() {
        val found = mutableListOf<RadarTarget>()
        var idx = 0

        try {
            wifiManager.startScan()
            wifiManager.scanResults?.forEach { res ->
                val ssid = res.SSID.ifBlank { "Gizli Ag" }
                val isMcu = ssid.contains("ESP", true) || ssid.contains("Arduino", true) || ssid.contains("NodeMCU", true)
                val normDist = ((-res.level - 30f) / 70f).coerceIn(0.15f, 0.95f)
                found.add(
                    RadarTarget(
                        name = ssid,
                        address = res.BSSID ?: "00:00",
                        type = if (isMcu) "ESP32/ARDUINO" else "WIFI",
                        rssi = res.level,
                        angleDeg = (idx * 47f) % 360f,
                        distanceNorm = normDist
                    )
                )
                idx++
            }
        } catch (_: Exception) {}

        try {
            val adapter: BluetoothAdapter? = btManager.adapter
            adapter?.bondedDevices?.forEach { dev ->
                val dName = dev.name ?: "BT Cihaz"
                val isMcu = dName.contains("HC-05", true) || dName.contains("HC-06", true) || dName.contains("ESP", true)
                found.add(
                    RadarTarget(
                        name = dName,
                        address = dev.address,
                        type = if (isMcu) "ESP32/ARDUINO" else "BLUETOOTH",
                        rssi = -55,
                        angleDeg = (idx * 63f + 20f) % 360f,
                        distanceNorm = 0.45f
                    )
                )
                idx++
            }
            adapter?.startDiscovery()
        } catch (_: Exception) {}

        try {
            usbManager.deviceList.values.forEach { usb ->
                found.add(
                    RadarTarget(
                        name = usb.productName ?: "USB Seri Kart (VID:${usb.vendorId})",
                        address = usb.deviceName,
                        type = "USB-OTG MCU",
                        rssi = -10,
                        angleDeg = 0f,
                        distanceNorm = 0.15f
                    )
                )
            }
        } catch (_: Exception) {}

        _radarTargets.value = found
    }

    @SuppressLint("MissingPermission")
    suspend fun sendCommandToEsp32(targetAddressOrIp: String, command: String): String = withContext(Dispatchers.IO) {
        if (targetAddressOrIp.contains(".")) {
            return@withContext try {
                Socket(targetAddressOrIp, 80).use { socket ->
                    socket.getOutputStream().write((command + "\n").toByteArray())
                    "ESP32 Wi-Fi ($targetAddressOrIp) uzerine '$command' sinyali iletildi efendim."
                }
            } catch (e: Exception) {
                "ESP32 IP baglantisi basarisiz: ${e.localizedMessage}"
            }
        }

        return@withContext try {
            val device: BluetoothDevice? = btManager.adapter?.getRemoteDevice(targetAddressOrIp)
            val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
            val socket = device?.createRfcommSocketToServiceRecord(sppUuid)
            socket?.connect()
            socket?.outputStream?.write((command + "\n").toByteArray())
            socket?.close()
            "Mikrodenetleyici ($targetAddressOrIp) Bluetooth koprusu uzerinden tetiklendi."
        } catch (e: Exception) {
            "Bluetooth seri baglantisi kurulamadi: ${e.localizedMessage}"
        }
    }

    suspend fun checkGitHubReleaseUpdate(repoSlug: String): String = withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient()
            val req = Request.Builder()
                .url("https://api.github.com/repos/$repoSlug/releases/latest")
                .header("User-Agent", "JARVIS-SelfUpdater")
                .build()
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return@withContext "GitHub ($repoSlug) deposunda henuz yayinlanmis yeni bir surum bulunamadi."
                val json = JSONObject(res.body?.string() ?: "{}")
                val tag = json.optString("tag_name", "v2.0.0")
                val assets = json.optJSONArray("assets")
                val downloadUrl = if (assets != null && assets.length() > 0) {
                    assets.getJSONObject(0).optString("browser_download_url", "")
                } else ""
                return@withContext "Son GitHub Surumu ($repoSlug): $tag\nAPK Indirme Linki: $downloadUrl"
            }
        } catch (e: Exception) {
            return@withContext "Guncelleme sunucusuna erisilemedi: ${e.localizedMessage}"
        }
    }
}
