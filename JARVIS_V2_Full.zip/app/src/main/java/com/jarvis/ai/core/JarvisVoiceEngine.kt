package com.jarvis.ai.core

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.jarvis.ai.data.JarvisVault
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.Locale

class JarvisVoiceEngine(
    private val context: Context,
    private val vault: JarvisVault,
    private val onSpeechResult: (String) -> Unit
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val client = OkHttpClient()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _soundAmplitude = MutableStateFlow(0f)
    val soundAmplitude: StateFlow<Float> = _soundAmplitude

    private val _voicesList = MutableStateFlow<List<Voice>>(emptyList())
    val voicesList: StateFlow<List<Voice>> = _voicesList

    init {
        tts = TextToSpeech(context, this)
        setupRecognizer()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("tr", "TR")
            tts?.voices?.filter { it.locale.language == "tr" || it.locale.language == "en" }?.let {
                _voicesList.value = it.sortedBy { v -> v.locale.language != "tr" }
            }
            applyVoiceSettings()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                    _soundAmplitude.value = 0.85f
                }
                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    _soundAmplitude.value = 0f
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    _soundAmplitude.value = 0f
                }
            })
        }
    }

    fun applyVoiceSettings() {
        tts?.setPitch(vault.voicePitch)
        tts?.setSpeechRate(vault.voiceRate)
        if (vault.selectedVoiceName.isNotBlank()) {
            _voicesList.value.firstOrNull { it.name == vault.selectedVoiceName }?.let {
                tts?.voice = it
            }
        }
    }

    private fun setupRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { _isListening.value = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {
                    _soundAmplitude.value = ((rmsdB + 2f) / 12f).coerceIn(0.15f, 1.0f)
                }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    _isListening.value = false
                    _soundAmplitude.value = 0f
                }
                override fun onError(error: Int) {
                    _isListening.value = false
                    _soundAmplitude.value = 0f
                }
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        onSpeechResult(matches[0])
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    fun startListening() {
        stopSpeaking()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.startListening(intent)
    }

    fun speak(rawText: String) {
        val cleanText = rawText.replace(Regex("\[CMD:.*?\]"), "").replace("*", "").trim()
        if (cleanText.isBlank()) return

        if (vault.elevenLabsApiKey.isNotBlank()) {
            speakWithElevenLabs(cleanText)
            return
        }

        applyVoiceSettings()
        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "JARVIS_UTTERANCE")
    }

    private fun speakWithElevenLabs(text: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                _isSpeaking.value = true
                _soundAmplitude.value = 0.8f
                val json = JSONObject()
                    .put("text", text)
                    .put("model_id", "eleven_multilingual_v2")
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val req = Request.Builder()
                    .url("https://api.elevenlabs.io/v1/text-to-speech/${vault.elevenLabsVoiceId}")
                    .header("xi-api-key", vault.elevenLabsApiKey)
                    .post(body)
                    .build()

                client.newCall(req).execute().use { res ->
                    if (res.isSuccessful) {
                        val bytes = res.body?.bytes()
                        if (bytes != null) {
                            val tempFile = File(context.cacheDir, "jarvis_clone.mp3")
                            tempFile.writeBytes(bytes)
                            val mp = MediaPlayer().apply {
                                setDataSource(tempFile.absolutePath)
                                prepare()
                                setOnCompletionListener {
                                    _isSpeaking.value = false
                                    _soundAmplitude.value = 0f
                                    it.release()
                                }
                                start()
                            }
                            return@launch
                        }
                    }
                }
                _isSpeaking.value = false
                _soundAmplitude.value = 0f
            } catch (e: Exception) {
                _isSpeaking.value = false
                _soundAmplitude.value = 0f
            }
        }
    }

    fun stopSpeaking() {
        tts?.stop()
        _isSpeaking.value = false
        _soundAmplitude.value = 0f
    }

    fun shutdown() {
        tts?.shutdown()
        speechRecognizer?.destroy()
    }
}
