package com.jarvis.ai.automation

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object JarvisLiveBuffer {
    val recentNotifications = mutableListOf<String>()
    var pendingWhatsAppAutoSend = false

    fun addNotification(text: String) {
        recentNotifications.add(text)
        if (recentNotifications.size > 25) recentNotifications.removeAt(0)
    }

    fun getSummary(): String = recentNotifications.takeLast(8).joinToString(" | ")
}

class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val pkg = sbn.packageName ?: return
        val extras = sbn.notification?.extras ?: return
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        if (title.isNotBlank() || text.isNotBlank()) {
            JarvisLiveBuffer.addNotification("[$pkg] $title: $text")
        }
    }
}

class JarvisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!JarvisLiveBuffer.pendingWhatsAppAutoSend) return
        val rootNode = rootInActiveWindow ?: return
        val sendNodes = rootNode.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send")
        if (!sendNodes.isNullOrEmpty()) {
            sendNodes[0].performAction(AccessibilityNodeInfo.ACTION_CLICK)
            JarvisLiveBuffer.pendingWhatsAppAutoSend = false
        }
    }

    override fun onInterrupt() {}
}

class JarvisPhoneAutonomy(private val context: Context) {

    @SuppressLint("Range")
    fun findContactNumber(nameQuery: String): String? {
        val clean = nameQuery.trim()
        if (clean.all { it.isDigit() || it == '+' || it == ' ' }) return clean.replace(" ", "")
        try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$clean%"),
                null
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    return it.getString(it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                        ?.replace(" ", "")?.replace("-", "")
                }
            }
        } catch (_: Exception) {}
        return null
    }

    fun callContact(target: String): String {
        val number = findContactNumber(target) ?: return "'$target' rehberde bulunamadi efendim."
        return try {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "$target ($number) araniyor efendim."
        } catch (e: Exception) {
            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(dialIntent)
            "Arama ekrani hazirlandi efendim: $number"
        }
    }

    fun sendWhatsAppMessage(target: String, message: String): String {
        val rawNumber = findContactNumber(target) ?: return "WhatsApp icin '$target' numarasi bulunamadi efendim."
        var formatted = rawNumber.replace("+", "")
        if (formatted.startsWith("0")) formatted = "90" + formatted.substring(1)
        return try {
            JarvisLiveBuffer.pendingWhatsAppAutoSend = true
            val encoded = URLEncoder.encode(message, "UTF-8")
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$formatted&text=$encoded")).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "$target kisisine WhatsApp mesaji iletiliyor efendim."
        } catch (e: Exception) {
            "WhatsApp uygulamasi acilamadi: ${e.localizedMessage}"
        }
    }

    fun openAnyApp(appName: String): String {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(0)
        val match = packages.firstOrNull {
            pm.getApplicationLabel(it).toString().contains(appName.trim(), ignoreCase = true)
        }
        return if (match != null) {
            val launch = pm.getLaunchIntentForPackage(match.packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (launch != null) {
                context.startActivity(launch)
                "${pm.getApplicationLabel(match)} baslatiliyor efendim."
            } else "Uygulama baslatilamadi."
        } else {
            "'$appName' cihazda yuklu gorunmuyor efendim."
        }
    }

    fun addCalendarEvent(title: String): String {
        return try {
            val startMillis = System.currentTimeMillis() + 3600_000L
            val values = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, startMillis)
                put(CalendarContract.Events.DTEND, startMillis + 3600_000L)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.CALENDAR_ID, 1)
                put(CalendarContract.Events.EVENT_TIMEZONE, "Europe/Istanbul")
            }
            context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            "'$title' takviminize eklendi efendim."
        } catch (e: Exception) {
            val intent = Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI).apply {
                putExtra(CalendarContract.Events.TITLE, title)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Takvim etkinligi olusturma ekrani acildi efendim."
        }
    }

    @SuppressLint("Range")
    fun searchSmartMedia(query: String): List<Pair<String, Uri>> {
        val results = mutableListOf<Pair<String, Uri>>()
        val q = query.lowercase().trim()
        val collections = listOf(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Files.getContentUri("external")
        )
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale("tr"))

        for (uri in collections) {
            try {
                val cursor = context.contentResolver.query(
                    uri,
                    arrayOf(
                        MediaStore.MediaColumns._ID,
                        MediaStore.MediaColumns.DISPLAY_NAME,
                        MediaStore.MediaColumns.DATE_ADDED
                    ),
                    null,
                    null,
                    "${MediaStore.MediaColumns.DATE_ADDED} DESC"
                )
                cursor?.use {
                    while (it.moveToNext() && results.size < 20) {
                        val id = it.getLong(it.getColumnIndex(MediaStore.MediaColumns._ID))
                        val name = it.getString(it.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)) ?: "Dosya"
                        val dateSec = it.getLong(it.getColumnIndex(MediaStore.MediaColumns.DATE_ADDED))
                        val dateStr = sdf.format(Date(dateSec * 1000L))

                        val matchMonth = q.contains("gecen ay") || q.contains("bu ay") || q.contains("bugun") || q.isBlank()
                        if (name.lowercase().contains(q) || dateStr.lowercase().contains(q) || matchMonth) {
                            val itemUri = ContentUris.withAppendedId(uri, id)
                            results.add("$name ($dateStr)" to itemUri)
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return results
    }
}
