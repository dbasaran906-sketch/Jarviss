package com.jarvis.ai.ui

import android.graphics.Bitmap
import android.view.ViewGroup
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.jarvis.ai.R
import com.jarvis.ai.hardware.RadarTarget
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.sin

val ArcCyan = Color(0xFF00E5FF)
val ArcBlue = Color(0xFF0077FF)
val ArcOrange = Color(0xFFFF6D00)
val HudBg = Color(0xFF03070E)

fun getThemeAccentColor(themeName: String): Color {
    return when (themeName) {
        "MARK85_GOLD" -> Color(0xFFFFB300)
        "STEALTH_GREEN" -> Color(0xFF00E676)
        "QUANTUM_PURPLE" -> Color(0xFFD500F9)
        else -> ArcCyan
    }
}

@Composable
fun JarvisSplashAnimation(onFinished: () -> Unit) {
    val scaleAnim = remember { Animatable(0.35f) }
    val alphaAnim = remember { Animatable(0f) }
    val ringRotation by rememberInfiniteTransition(label = "splash").animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "rot"
    )

    LaunchedEffect(Unit) {
        alphaAnim.animateTo(1f, tween(900))
        scaleAnim.animateTo(1.06f, tween(1700, easing = FastOutSlowInEasing))
        scaleAnim.animateTo(1.0f, tween(600))
        kotlinx.coroutines.delay(500)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HudBg),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(340.dp)) {
            rotate(ringRotation) {
                drawCircle(
                    color = ArcCyan.copy(alpha = 0.55f),
                    radius = size.minDimension / 2f,
                    style = Stroke(width = 4f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(30f, 18f)))
                )
            }
            rotate(-ringRotation * 1.5f) {
                drawCircle(
                    color = ArcBlue.copy(alpha = 0.75f),
                    radius = size.minDimension / 2.3f,
                    style = Stroke(width = 6f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(60f, 25f)))
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .scale(scaleAnim.value)
                .alpha(alphaAnim.value)
        ) {
            Image(
                painter = painterResource(id = R.drawable.jarvis_logo),
                contentDescription = "JARVIS Logo",
                modifier = Modifier.size(210.dp)
            )
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "J.A.R.V.I.S. V2",
                color = ArcCyan,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "HOLOGRAFIK HUD VE OTONOM CEKIRDEK AKTIF",
                color = ArcCyan.copy(alpha = 0.75f),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun HolographicArcReactor(
    themeName: String,
    isThinking: Boolean,
    isSpeaking: Boolean,
    amplitude: Float,
    onReactorClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "reactor")
    val baseRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isThinking) 2000 else 8500, easing = LinearEasing)
        ),
        label = "outerRot"
    )
    val reverseRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isThinking) 1500 else 6000, easing = LinearEasing)
        ),
        label = "innerRot"
    )

    val themeAccent = getThemeAccentColor(themeName)
    val primaryColor = if (isThinking) ArcOrange else themeAccent
    val dynamicScale = 1f + (if (isSpeaking) amplitude * 0.28f else 0f)

    Box(
        modifier = Modifier
            .size(215.dp)
            .scale(dynamicScale)
            .clickable { onReactorClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxR = size.minDimension / 2f

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(primaryColor.copy(alpha = 0.40f), Color.Transparent),
                    center = center,
                    radius = maxR
                ),
                radius = maxR
            )

            rotate(baseRotation, pivot = center) {
                drawCircle(
                    color = primaryColor,
                    radius = maxR * 0.88f,
                    style = Stroke(
                        width = 8f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(45f, 20f, 12f, 20f))
                    )
                )
            }

            rotate(reverseRotation, pivot = center) {
                drawCircle(
                    color = primaryColor.copy(alpha = 0.82f),
                    radius = maxR * 0.68f,
                    style = Stroke(
                        width = 12f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(28f, 14f))
                    )
                )
            }

            val spokeCount = 24
            for (i in 0 until spokeCount) {
                val angle = Math.toRadians((i * (360.0 / spokeCount)) + baseRotation)
                val waveBoost = if (isSpeaking) (sin(i * 1.5 + baseRotation * 0.1) * 20f * amplitude).toFloat() else 0f
                val rStart = maxR * 0.42f
                val rEnd = maxR * 0.55f + waveBoost
                drawLine(
                    color = primaryColor,
                    start = Offset(center.x + cos(angle).toFloat() * rStart, center.y + sin(angle).toFloat() * rStart),
                    end = Offset(center.x + cos(angle).toFloat() * rEnd, center.y + sin(angle).toFloat() * rEnd),
                    strokeWidth = 4f,
                    cap = StrokeCap.Round
                )
            }

            drawCircle(color = Color.White, radius = maxR * 0.24f)
            drawCircle(color = primaryColor, radius = maxR * 0.30f, style = Stroke(width = 6f))
        }

        Text(
            text = when {
                isThinking -> "ANALIZ"
                isSpeaking -> "AKTIF"
                else -> "DINLE"
            },
            color = HudBg,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun HardwareRadarHud(
    targets: List<RadarTarget>,
    onScanClick: () -> Unit,
    onTargetSelect: (RadarTarget) -> Unit
) {
    val sweep by rememberInfiniteTransition(label = "radar").animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2800, easing = LinearEasing)),
        label = "sweep"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "AKTIF SINYAL VE ESP32/ARDUINO RADARI (${targets.size} TESPIT)",
            color = ArcCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(8.dp))

        Canvas(modifier = Modifier.size(210.dp)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val r = size.minDimension / 2f
            for (step in 1..3) {
                drawCircle(
                    color = ArcCyan.copy(alpha = 0.35f),
                    radius = r * (step / 3f),
                    style = Stroke(width = 2f)
                )
            }
            val rad = Math.toRadians(sweep.toDouble())
            drawLine(
                color = ArcCyan,
                start = c,
                end = Offset(c.x + cos(rad).toFloat() * r, c.y + sin(rad).toFloat() * r),
                strokeWidth = 4f
            )
            targets.forEach { t ->
                val a = Math.toRadians(t.angleDeg.toDouble())
                val dist = r * t.distanceNorm
                val dotColor = if (t.type.contains("ESP") || t.type.contains("USB")) ArcOrange else Color.Green
                drawCircle(
                    color = dotColor,
                    radius = 9f,
                    center = Offset(c.x + cos(a).toFloat() * dist, c.y + sin(a).toFloat() * dist)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onScanClick,
            colors = ButtonDefaults.buttonColors(containerColor = ArcBlue)
        ) {
            Text("CEVREYI TARA (WI-FI / BT / ESP32 / USB)", color = Color.White, fontSize = 11.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))
        targets.take(7).forEach { target ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .border(1.dp, ArcCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .clickable { onTargetSelect(target) }
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("${target.name} [${target.type}]", color = Color.White, fontSize = 12.sp)
                Text("${target.rssi} dBm", color = ArcCyan, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun IronManCameraHudOverlay(
    hudOverlayText: String,
    useFrontCamera: Boolean,
    onToggleCamera: () -> Unit,
    onAnalyzeFrame: (Bitmap, String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var latestBitmap by remember { mutableStateOf<Bitmap?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx ->
                PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { previewView ->
                val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                    val imageAnalyzer = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                        .also { analysis ->
                            analysis.setAnalyzer(Executors.newSingleThreadExecutor()) { proxy: ImageProxy ->
                                latestBitmap = proxy.toBitmap()
                                proxy.close()
                            }
                        }
                    val selector = if (useFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                    try {
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview, imageAnalyzer)
                    } catch (_: Exception) {}
                }, ContextCompat.getMainExecutor(context))
            },
            modifier = Modifier.fillMaxSize()
        )

        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            drawRect(
                color = ArcCyan.copy(alpha = 0.75f),
                topLeft = Offset(cx - 145f, cy - 145f),
                size = androidx.compose.ui.geometry.Size(290f, 290f),
                style = Stroke(width = 3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(25f, 15f)))
            )
            drawCircle(color = ArcOrange, radius = 8f, center = Offset(cx, cy))
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(10.dp)
                .background(HudBg.copy(alpha = 0.82f), RoundedCornerShape(10.dp))
                .border(1.dp, ArcCyan, RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Text(
                text = "MARK-LXXXV GORSEL OTONOMI & ALTYAZI HUD",
                color = ArcOrange,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = hudOverlayText.ifBlank { "Devre karti, kablo, mimik/el hareketi veya yabanci dil metin taramaya hazir." },
                color = ArcCyan,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(HudBg.copy(alpha = 0.88f))
                .padding(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = { latestBitmap?.let { onAnalyzeFrame(it, "Kameradaki devre kartini, kablolari veya bilesenleri teknik etiketleriyle tanimla.") } },
                    colors = ButtonDefaults.buttonColors(containerColor = ArcBlue)
                ) {
                    Text("DEVRE / KABLO", fontSize = 10.sp)
                }
                Button(
                    onClick = { latestBitmap?.let { onAnalyzeFrame(it, "Kameradaki kisinin mimiklerini, yuz ifadesini ve el hareketlerini analiz edip niyetini tahmin et.") } },
                    colors = ButtonDefaults.buttonColors(containerColor = ArcOrange)
                ) {
                    Text("MIMIK / EL OKU", fontSize = 10.sp)
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = { latestBitmap?.let { onAnalyzeFrame(it, "Kameradaki tum yabanci dildeki yazilari ve tabelalari tespit edip aninda Turkce HUD altyazisi olarak cevir.") } },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00695C))
                ) {
                    Text("CANLI CEVIRI HUD", fontSize = 10.sp)
                }
                Button(
                    onClick = onToggleCamera,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                ) {
                    Text(if (useFrontCamera) "ARKA KAMERA" else "ON KAMERA", fontSize = 10.sp)
                }
            }
        }
    }
}
