package com.jarvis.ai

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.automation.JarvisLiveBuffer
import com.jarvis.ai.automation.JarvisPhoneAutonomy
import com.jarvis.ai.core.JarvisBrain
import com.jarvis.ai.core.JarvisVoiceEngine
import com.jarvis.ai.data.ChatMessage
import com.jarvis.ai.data.JarvisVault
import com.jarvis.ai.hardware.JarvisHardwareManager
import com.jarvis.ai.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JarvisMainApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisMainApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val vault = remember { JarvisVault(context) }
    val brain = remember { JarvisBrain(context, vault) }
    val hardware = remember { JarvisHardwareManager(context) }
    val autonomy = remember { JarvisPhoneAutonomy(context) }

    var showSplash by remember { mutableStateOf(true) }
    var activeTab by remember { mutableIntStateOf(0) } // 0: HUD, 1: VIZOR, 2: RADAR, 3: KASA/DOSYA, 4: AYARLAR
    var inputText by remember { mutableStateOf("") }
    var isThinking by remember { mutableStateOf(false) }
    var hudCameraResult by remember { mutableStateOf("") }
    var useFrontCamera by remember { mutableStateOf(false) }
    var selectedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var selectedMediaUri by remember { mutableStateOf<Uri?>(null) }
    var currentTheme by remember { mutableStateOf(vault.hudThemeName) }

    val messages = remember {
        mutableStateListOf<ChatMessage>().apply {
            val saved = vault.loadChatHistory()
            if (saved.isEmpty()) {
                add(
                    ChatMessage(
                        text = "Tum sistemler cevrimici efendim. Ark Reaktoru stabil. Size nasil yardimci olabilirim?",
                        isJarvis = true,
                        timestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                    )
                )
            } else {
                addAll(saved)
            }
        }
    }

    lateinit var voiceEngine: JarvisVoiceEngine
    voiceEngine = remember {
        JarvisVoiceEngine(context, vault) { spokenText ->
            inputText = spokenText
        }
    }

    val isSpeaking by voiceEngine.isSpeaking.collectAsState()
    val isListening by voiceEngine.isListening.collectAsState()
    val amplitude by voiceEngine.soundAmplitude.collectAsState()
    val telemetry by hardware.telemetrySummary.collectAsState()
    val radarTargets by hardware.radarTargets.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        hardware.startSensors()
        hardware.scanEnvironmentRadar()
    }

    val mediaPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val mime = context.contentResolver.getType(it) ?: ""
            if (mime.startsWith("image")) {
                val bmp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, it))
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, it)
                }
                selectedBitmap = bmp
                selectedMediaUri = null
            } else {
                selectedMediaUri = it
                selectedBitmap = null
            }
        }
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.READ_CALENDAR,
                Manifest.permission.WRITE_CALENDAR,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            )
        )
    }

    LaunchedEffect(vault.sensorReportIntervalHours) {
        while (true) {
            val hours = vault.sensorReportIntervalHours.coerceAtLeast(1)
            delay(hours * 3600_000L)
            val report = "Efendim, periyodik cihaz ve sensor raporu: ${hardware.telemetrySummary.value}"
            messages.add(ChatMessage(text = report, isJarvis = true, timestamp = "OTO"))
            voiceEngine.speak(report)
        }
    }

    fun executeAutonomousTags(aiResponse: String): String {
        var display = aiResponse
        val regex = Regex("\[CMD:(.*?)\]")
        val matches = regex.findAll(aiResponse)
        for (m in matches) {
            val parts = m.groupValues[1].split(":")
            val action = parts.getOrNull(0) ?: ""
            val param = parts.drop(1).joinToString(":")
            val execResult = when (action) {
                "CALL" -> autonomy.callContact(param)
                "WHATSAPP" -> {
                    val wp = param.split("|")
                    autonomy.sendWhatsAppMessage(wp.getOrElse(0) { "" }, wp.getOrElse(1) { "" })
                }
                "OPEN_APP" -> autonomy.openAnyApp(param)
                "CALENDAR" -> autonomy.addCalendarEvent(param.substringBefore("|"))
                "SAVE_PASS" -> {
                    val sp = param.split("|")
                    vault.savePassword(sp.getOrElse(0) { "genel" }, sp.getOrElse(1) { "" })
                    "Sifre sifreli kasaya kaydedildi efendim."
                }
                "GET_PASS" -> vault.getPassword(param) ?: "Kasada bu isimle sifre bulunamadi."
                "FIND_MEDIA" -> {
                    val found = autonomy.searchSmartMedia(param)
                    if (found.isEmpty()) "Eslesen medya dosyasi bulunamadi."
                    else "Bulunan dosyalar:\n" + found.joinToString("\n") { "• ${it.first}" }
                }
                else -> ""
            }
            if (execResult.isNotBlank()) {
                display += "\n\n[SISTEM ISLEMI]: $execResult"
            }
        }
        return display.replace(regex, "").trim()
    }

    fun sendPrompt(promptText: String) {
        if (promptText.isBlank() && selectedBitmap == null && selectedMediaUri == null) return
        val now = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val attachBmp = selectedBitmap
        val attachUri = selectedMediaUri
        val label = when {
            attachBmp != null -> "[Fotograf Analizi] $promptText"
            attachUri != null -> "[Video/Ses Analizi] $promptText"
            else -> promptText
        }
        messages.add(ChatMessage(text = label.trim(), isJarvis = false, timestamp = now))
        inputText = ""
        selectedBitmap = null
        selectedMediaUri = null
        isThinking = true

        scope.launch {
            var extraInfo = ""
            if (promptText.contains("hava", true) || promptText.contains("derece", true)) {
                extraInfo += brain.fetchLiveWeather("Istanbul") + "\n"
            }
            if (promptText.contains("guncelle", true) || promptText.contains("update", true)) {
                extraInfo += hardware.checkGitHubReleaseUpdate(vault.githubRepoSlug) + "\n"
            }
            if (promptText.contains("sifrelerim", true)) {
                extraInfo += vault.listAllPasswords() + "\n"
            }

            val rawReply = brain.askJarvis(
                userPrompt = promptText.ifBlank { "Gonderilen bu medya dosyasini ses ve goruntu olarak detayli analiz et." },
                bitmap = attachBmp,
                mediaUri = attachUri,
                extraContext = extraInfo,
                sensorContext = telemetry,
                recentNotifications = JarvisLiveBuffer.getSummary()
            )
            val finalReply = executeAutonomousTags(rawReply)
            isThinking = false
            messages.add(ChatMessage(text = finalReply, isJarvis = true, timestamp = now))
            vault.saveChatHistory(messages)
            voiceEngine.speak(finalReply)
        }
    }

    if (showSplash) {
        JarvisSplashAnimation { showSplash = false }
        return
    }

    val accent = getThemeAccentColor(currentTheme)

    Scaffold(
        containerColor = HudBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("J.A.R.V.I.S.", color = accent, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text(telemetry, color = accent.copy(alpha = 0.7f), fontSize = 9.sp, maxLines = 1)
                    }
                },
                actions = {
                    IconButton(onClick = { activeTab = 4 }) {
                        Icon(Icons.Default.Settings, contentDescription = "Ayarlar", tint = accent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = HudBg)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF060D1A)) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(Icons.Default.GraphicEq, contentDescription = null) },
                    label = { Text("HUD", fontSize = 9.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(Icons.Default.Visibility, contentDescription = null) },
                    label = { Text("VIZOR", fontSize = 9.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2; hardware.scanEnvironmentRadar() },
                    icon = { Icon(Icons.Default.Radar, contentDescription = null) },
                    label = { Text("RADAR", fontSize = 9.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { activeTab = 3 },
                    icon = { Icon(Icons.Default.FolderSpecial, contentDescription = null) },
                    label = { Text("KASA", fontSize = 9.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == 4,
                    onClick = { activeTab = 4 },
                    icon = { Icon(Icons.Default.Tune, contentDescription = null) },
                    label = { Text("AYAR", fontSize = 9.sp) }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (activeTab) {
                0 -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            HolographicArcReactor(
                                themeName = currentTheme,
                                isThinking = isThinking,
                                isSpeaking = isSpeaking,
                                amplitude = if (isListening || isSpeaking) amplitude.coerceAtLeast(0.45f) else 0f,
                                onReactorClick = { voiceEngine.startListening() }
                            )
                        }

                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp)
                        ) {
                            items(messages) { msg ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .background(
                                            if (msg.isJarvis) Color(0xFF081629) else Color(0xFF102038),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            1.dp,
                                            if (msg.isJarvis) accent.copy(alpha = 0.45f) else ArcOrange.copy(alpha = 0.45f),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(10.dp)
                                ) {
                                    Text(
                                        text = msg.text,
                                        color = if (msg.isJarvis) Color(0xFFE0F7FA) else Color.White,
                                        fontSize = 14.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF060E1C))
                                .padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { mediaPickerLauncher.launch("*/*") }) {
                                Icon(
                                    Icons.Default.AttachFile,
                                    contentDescription = "Foto/Video/Ses Ekle",
                                    tint = if (selectedBitmap != null || selectedMediaUri != null) ArcOrange else accent
                                )
                            }
                            OutlinedTextField(
                                value = inputText,
                                onValueChange = { inputText = it },
                                placeholder = { Text("Komut, karar analizi veya kod...", color = Color.Gray, fontSize = 12.sp) },
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = accent,
                                    unfocusedBorderColor = accent.copy(alpha = 0.4f)
                                )
                            )
                            IconButton(onClick = { voiceEngine.startListening() }) {
                                Icon(
                                    Icons.Default.Mic,
                                    contentDescription = "Sesli Komut",
                                    tint = if (isListening) ArcOrange else accent
                                )
                            }
                            IconButton(onClick = { sendPrompt(inputText) }) {
                                Icon(Icons.Default.Send, contentDescription = "Gonder", tint = accent)
                            }
                        }
                    }
                }

                1 -> {
                    IronManCameraHudOverlay(
                        hudOverlayText = hudCameraResult,
                        useFrontCamera = useFrontCamera,
                        onToggleCamera = { useFrontCamera = !useFrontCamera },
                        onAnalyzeFrame = { bmp, query ->
                            hudCameraResult = "Taraniyor ve analiz ediliyor..."
                            scope.launch {
                                val res = brain.askJarvis(query, bitmap = bmp)
                                hudCameraResult = res
                                voiceEngine.speak(res)
                            }
                        }
                    )
                }

                2 -> {
                    HardwareRadarHud(
                        targets = radarTargets,
                        onScanClick = { hardware.scanEnvironmentRadar() },
                        onTargetSelect = { target ->
                            scope.launch {
                                val status = hardware.sendCommandToEsp32(target.address, "STATUS_PING")
                                messages.add(ChatMessage(text = status, isJarvis = true, timestamp = "MCU"))
                                activeTab = 0
                                voiceEngine.speak(status)
                            }
                        }
                    )
                }

                3 -> {
                    VaultAndMediaScreen(vault = vault, autonomy = autonomy)
                }

                4 -> {
                    JarvisSettingsScreen(
                        vault = vault,
                        voiceEngine = voiceEngine,
                        onThemeChanged = { currentTheme = it },
                        onClearHistory = {
                            vault.clearChatHistory()
                            messages.clear()
                        },
                        onCheckUpdate = {
                            scope.launch {
                                val info = hardware.checkGitHubReleaseUpdate(vault.githubRepoSlug)
                                messages.add(ChatMessage(text = info, isJarvis = true, timestamp = "UPD"))
                                activeTab = 0
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun VaultAndMediaScreen(vault: JarvisVault, autonomy: JarvisPhoneAutonomy) {
    val context = LocalContext.current
    var serviceName by remember { mutableStateOf("") }
    var secretPass by remember { mutableStateOf("") }
    var savedPasswords by remember { mutableStateOf(vault.getAllPasswordPairs()) }

    var mediaQuery by remember { mutableStateOf("") }
    var foundMedia by remember { mutableStateOf<List<Pair<String, Uri>>>(emptyList()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        Text("AES-256 SIFRELI PAROLA KASASI", color = ArcCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = serviceName,
                onValueChange = { serviceName = it },
                placeholder = { Text("Uygulama/Site", fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
            )
            Spacer(modifier = Modifier.width(6.dp))
            OutlinedTextField(
                value = secretPass,
                onValueChange = { secretPass = it },
                placeholder = { Text("Sifre", fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
            )
        }
        Button(
            onClick = {
                if (serviceName.isNotBlank() && secretPass.isNotBlank()) {
                    vault.savePassword(serviceName, secretPass)
                    savedPasswords = vault.getAllPasswordPairs()
                    serviceName = ""
                    secretPass = ""
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ArcBlue)
        ) {
            Text("SIFREYI KASAYA KILITLE", color = Color.White, fontSize = 12.sp)
        }

        savedPasswords.forEach { (srv, pwd) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
                    .border(1.dp, ArcCyan.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("$srv : $pwd", color = Color.White, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                IconButton(onClick = {
                    vault.deletePassword(srv)
                    savedPasswords = vault.getAllPasswordPairs()
                }) {
                    Icon(Icons.Default.Delete, contentDescription = "Sil", tint = ArcOrange)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("AKILLI MEDYA VE BELGE BULUCU", color = ArcOrange, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = mediaQuery,
            onValueChange = { mediaQuery = it },
            placeholder = { Text("Orn: gecen ay, ekran goruntusu, fatura...", fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
        )
        Button(
            onClick = { foundMedia = autonomy.searchSmartMedia(mediaQuery) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ArcOrange)
        ) {
            Text("TELEFON HAFIZASINDA ARA", color = Color.White, fontSize = 12.sp)
        }

        foundMedia.forEach { (title, uri) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .background(Color(0xFF0A192F), RoundedCornerShape(6.dp))
                    .clickable {
                        try {
                            val openIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(openIntent)
                        } catch (_: Exception) {}
                    }
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(title, color = ArcCyan, fontSize = 12.sp)
                Text("AC", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun JarvisSettingsScreen(
    vault: JarvisVault,
    voiceEngine: JarvisVoiceEngine,
    onThemeChanged: (String) -> Unit,
    onClearHistory: () -> Unit,
    onCheckUpdate: () -> Unit
) {
    var geminiKey by remember { mutableStateOf(vault.geminiApiKey) }
    var elevenKey by remember { mutableStateOf(vault.elevenLabsApiKey) }
    var elevenVoiceId by remember { mutableStateOf(vault.elevenLabsVoiceId) }
    var repoSlug by remember { mutableStateOf(vault.githubRepoSlug) }
    var pitch by remember { mutableFloatStateOf(vault.voicePitch) }
    var rate by remember { mutableFloatStateOf(vault.voiceRate) }
    var sarcasm by remember { mutableFloatStateOf(vault.sarcasmLevel.toFloat()) }
    var intervalHours by remember { mutableFloatStateOf(vault.sensorReportIntervalHours.toFloat()) }
    var selectedTheme by remember { mutableStateOf(vault.hudThemeName) }
    var selectedVoice by remember { mutableStateOf(vault.selectedVoiceName) }
    val voices by voiceEngine.voicesList.collectAsState()
    var savedBanner by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
    ) {
        Text("JARVIS V2 CEKIRDEK VE ARAYUZ AYARLARI", color = ArcCyan, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = geminiKey,
            onValueChange = { geminiKey = it },
            label = { Text("Gemini API Anahtari (Zorunlu Beyin)", color = ArcCyan) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = elevenKey,
            onValueChange = { elevenKey = it },
            label = { Text("ElevenLabs API Anahtari (Ses Taklidi)", color = ArcCyan) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = elevenVoiceId,
            onValueChange = { elevenVoiceId = it },
            label = { Text("Taklit Edilecek Ses ID (Voice ID)", color = ArcCyan) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = repoSlug,
            onValueChange = { repoSlug = it },
            label = { Text("GitHub Guncelleme Deposu", color = ArcCyan) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
        )

        Spacer(modifier = Modifier.height(12.dp))
        Text("3D HOLOGRAFIK HUD TEMASI:", color = ArcOrange, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("ARC_BLUE" to "Mavi", "MARK85_GOLD" to "Altin", "STEALTH_GREEN" to "Yesil", "QUANTUM_PURPLE" to "Mor").forEach { (code, label) ->
                Button(
                    onClick = {
                        selectedTheme = code
                        vault.hudThemeName = code
                        onThemeChanged(code)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTheme == code) ArcBlue else Color.DarkGray
                    )
                ) {
                    Text(label, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text("SES KARAKTERI CESITLERI (${voices.size} Motor):", color = ArcCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        voices.take(5).forEach { v ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
                    .border(1.dp, if (selectedVoice == v.name) ArcOrange else Color.DarkGray, RoundedCornerShape(6.dp))
                    .clickable {
                        selectedVoice = v.name
                        vault.selectedVoiceName = v.name
                        voiceEngine.applyVoiceSettings()
                        voiceEngine.speak("Ses profili guncellendi efendim.")
                    }
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("${v.locale.displayLanguage} - ${v.name.takeLast(14)}", color = Color.White, fontSize = 12.sp)
                if (selectedVoice == v.name) Text("AKTIF", color = ArcOrange, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text("Ses Tonu Kalinligi (Pitch): ${String.format("%.2f", pitch)}", color = Color.White, fontSize = 13.sp)
        Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.6f..1.4f)

        Text("Konusma Hizi (Rate): ${String.format("%.2f", rate)}", color = Color.White, fontSize = 13.sp)
        Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.7f..1.5f)

        Text("Ince Sitem ve Mizah Seviyesi: %${sarcasm.toInt()}", color = Color.White, fontSize = 13.sp)
        Slider(value = sarcasm, onValueChange = { sarcasm = it }, valueRange = 0f..100f)

        Text("Otomatik Sensor Rapor Suresi: ${intervalHours.toInt()} Saat", color = Color.White, fontSize = 13.sp)
        Slider(value = intervalHours, onValueChange = { intervalHours = it }, valueRange = 1f..12f)

        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = {
                vault.geminiApiKey = geminiKey
                vault.elevenLabsApiKey = elevenKey
                vault.elevenLabsVoiceId = elevenVoiceId
                vault.githubRepoSlug = repoSlug
                vault.voicePitch = pitch
                vault.voiceRate = rate
                vault.sarcasmLevel = sarcasm.toInt()
                vault.sensorReportIntervalHours = intervalHours.toInt()
                voiceEngine.applyVoiceSettings()
                savedBanner = true
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ArcBlue)
        ) {
            Text("TUM AYARLARI KAYDET VE UYGULA", color = Color.White, fontWeight = FontWeight.Bold)
        }

        if (savedBanner) {
            Text("Tum ayarlar sifreli kasaya kaydedildi efendim.", color = Color.Green, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onCheckUpdate,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ArcOrange)
        ) {
            Text("GITHUB (jarviss) UZERINDEN GUNCELLEME KONTROL ET", color = Color.White)
        }

        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onClearHistory,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F0000))
        ) {
            Text("SOHBET GECMISINI TEMIZLE", color = Color.White)
        }
    }
}
